package com.exemplo.api.controller;

import com.exemplo.api.logger.AppLogger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private final AppLogger logger = AppLogger.getInstance();

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> tratarExcecao(Exception e) {
        logger.erro("Exceção não tratada: " + e.getClass().getSimpleName());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("erro", "Ocorreu um erro interno no servidor."));
    }
}
